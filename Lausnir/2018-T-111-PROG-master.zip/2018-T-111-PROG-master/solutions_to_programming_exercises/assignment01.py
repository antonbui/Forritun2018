a = int(input("Please enter an integer: "))
b = int(input("Please enter an integer: "))

result = a + b

print("The sum is:", result)