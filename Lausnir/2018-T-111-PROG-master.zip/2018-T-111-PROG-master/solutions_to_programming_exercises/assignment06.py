celsius = int(input("Please input a temperature in celcius: "))

fahrenheit_value = celsius * (9 / 5) + 32

print(celsius, "degrees celsius are", fahrenheit_value, "fahrenheit")