multiplier = int(input("Please input a multiplier: "))

for number in range(2, 16) :
    print(number * multiplier)