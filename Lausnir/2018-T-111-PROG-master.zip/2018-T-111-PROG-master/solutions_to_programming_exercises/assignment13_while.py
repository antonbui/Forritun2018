counter = -5

while counter <= 10 :
    print(counter)
    counter += 1