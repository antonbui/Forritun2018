counter = 3

while counter <= 13 :
    print(counter * 2)
    counter += 1