for number in range(3, 14) :
    print(number * 2)