turns = int(input("Input the number of turns: "))

counter = 0

while counter < turns :
    choice = input("input a number: ")
    print("You picked", choice)
    counter += 1
