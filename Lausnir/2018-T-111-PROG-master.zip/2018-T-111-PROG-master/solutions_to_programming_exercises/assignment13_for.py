for number in range(-5, 11) :
    print(number)