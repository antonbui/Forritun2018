for number in range(1, 11) :
    print(number)