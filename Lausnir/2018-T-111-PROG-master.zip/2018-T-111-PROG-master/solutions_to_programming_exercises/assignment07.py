a = int(input("Please input an integer: "))
b = int(input("Please input another integer: "))

if a == b :
    print("The numbers are equal")
elif a > b :
  print(a, "is greater")
else :
   print(b, "is greater")