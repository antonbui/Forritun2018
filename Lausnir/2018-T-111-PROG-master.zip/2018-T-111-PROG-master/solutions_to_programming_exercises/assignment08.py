a = input("Please input a string: ")
b = input("Please input another string: ")

if len(a) == len(b) :
    print("The string are the same length.")