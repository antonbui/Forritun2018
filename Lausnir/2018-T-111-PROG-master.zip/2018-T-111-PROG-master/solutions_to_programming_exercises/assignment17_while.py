counter = 15

while counter > 0 :
    if counter % 2 == 1 :
        print(counter)
    counter -= 1
