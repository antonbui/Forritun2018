age = int(input("What is your age? "))
name = input("What is your name? ")

print("Hello, my name is", name, "and my age is", age)