firstname = input("What is your first name? ")
lastname = input("What is your last name? ")

fullname = firstname + " " + lastname

print("Your fullname is", fullname)