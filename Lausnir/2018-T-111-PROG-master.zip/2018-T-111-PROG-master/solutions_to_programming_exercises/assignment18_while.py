low = int(input("Input the lower bound: "))
high = int(input("Input the higher bound: "))

while low <= high :
    print(low)
    low += 1
