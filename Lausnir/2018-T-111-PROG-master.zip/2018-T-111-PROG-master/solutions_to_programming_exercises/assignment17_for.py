for number in range(15, 0, -1) :
    if number % 2 == 1 :
        print(number)