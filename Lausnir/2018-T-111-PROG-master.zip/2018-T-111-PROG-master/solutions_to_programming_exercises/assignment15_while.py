multiplier = int(input("Please input a multiplier: "))

counter = 2

while counter <= 15 :
    print(counter * multiplier)
    counter += 1