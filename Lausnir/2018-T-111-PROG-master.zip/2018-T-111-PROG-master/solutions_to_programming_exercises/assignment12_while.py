counter = 1

while counter <= 10 :
    print(counter)
    counter += 1