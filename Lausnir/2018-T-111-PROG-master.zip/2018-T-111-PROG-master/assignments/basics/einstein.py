m_str = input('Input m: ')
m = float(m_str)
c = 3e8
e = m*c**2
print("e =", e)
