num = int(input("Input an int: "))
count = 1

while count < num:
    print(count)
    count += 1