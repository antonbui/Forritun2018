num = int(input("Input an int: "))
i = 1

while i <= num:
        print(i*2-1)
        i += 1


