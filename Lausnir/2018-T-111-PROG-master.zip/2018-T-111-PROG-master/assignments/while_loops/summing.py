num = int(input("Input an int: "))
total = 0

while num != 10:
	total += num
	num = int(input("Input an int: "))
print(total)