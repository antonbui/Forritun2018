s = input("Input a string: ")
s = s[3:] + s[:3]
print(s)