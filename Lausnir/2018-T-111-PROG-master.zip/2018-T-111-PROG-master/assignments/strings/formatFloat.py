s = input("Input a float: ")
f = float(s)
print("{:>12.2f}".format(f))