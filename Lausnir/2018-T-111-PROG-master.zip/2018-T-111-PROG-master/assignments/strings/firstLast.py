s = input("Input a string: ")
print(s[0],s[-1])