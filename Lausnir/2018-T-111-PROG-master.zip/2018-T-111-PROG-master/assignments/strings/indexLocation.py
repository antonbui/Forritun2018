s = input("Input a string: ")
for i,c in enumerate(s):
    if c == 'o':
        print(i)