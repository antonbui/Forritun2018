num = int(input("Input an int: "))

for i in range(num):
    print(i*2+1)

