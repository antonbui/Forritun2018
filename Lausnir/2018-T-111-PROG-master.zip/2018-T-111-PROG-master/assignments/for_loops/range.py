num = int(input("Input an int: "))
for i in range(1, num):
    print(i)