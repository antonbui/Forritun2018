grains = 0
for i in range(0, 64):
    grains += 2**i
print(grains)
