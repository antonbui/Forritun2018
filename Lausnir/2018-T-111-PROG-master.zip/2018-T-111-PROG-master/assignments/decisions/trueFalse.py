num = int(input("Input a number: ")) # Do not change this line

# Fill in the missing code
if num:
    print(True)
else:
    print(False)