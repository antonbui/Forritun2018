num = int(input("Input a number: ")) # Do not change this line

# Fill in the missing code

if num < 0: 
    print("Negative") # Do not change this line
elif num > 0:
    print("Positive") # Do not change this line
else:
    print("Zero") # Do not change this line